 <!-- footer area start-->
 <footer>
            <div class="footer-area">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> | Fit Stop Gym Management System</a>
            </div>
        </footer>
        <!-- footer area end-->

     